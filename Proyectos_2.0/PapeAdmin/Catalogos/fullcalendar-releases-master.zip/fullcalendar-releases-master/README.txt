
These release files were previously served on fullcalendar.io, however,
now all release files are served from the CDN.
